# backend/utils/material_faq.py

faq_materiais = [
    {
        "pergunta": "O que é concreto autoadensável?",
        "resposta": "É um tipo de concreto que se espalha sozinho nas formas, sem a necessidade de vibração mecânica. Ele melhora a qualidade da estrutura e reduz o tempo de execução da obra."
    },
    {
        "pergunta": "O que é concreto translúcido?",
        "resposta": "É um tipo de concreto que incorpora fibras ópticas, permitindo a passagem parcial da luz. Ele combina resistência estrutural com efeito estético inovador."
    },
    {
        "pergunta": "Para que serve o concreto com grafeno?",
        "resposta": "O concreto com grafeno tem maior resistência, durabilidade e propriedades térmicas. É um material promissor para construções mais sustentáveis e duráveis."
    },
    {
        "pergunta": "O que é cimento fotocatalítico?",
        "resposta": "É um tipo de cimento que ajuda a limpar o ar ao redor, reagindo com a luz solar para reduzir poluentes. Muito usado em pavimentos e fachadas sustentáveis."
    },
    {
        "pergunta": "O que é madeira engenheirada?",
        "resposta": "São produtos como CLT (Cross Laminated Timber), que utilizam camadas de madeira coladas em ângulos diferentes. Oferecem alta resistência e sustentabilidade em construções."
    },
    {
        "pergunta": "O que são tijolos ecológicos?",
        "resposta": "São blocos fabricados com solo-cimento e prensagem a seco, sem queima. Reduzem o impacto ambiental e têm encaixe preciso, diminuindo o uso de argamassa."
    },
    {
        "pergunta": "O que é concreto autorreparável?",
        "resposta": "É um concreto que contém cápsulas ou bactérias que selam fissuras automaticamente, aumentando a vida útil da estrutura e reduzindo manutenção."
    },
    {
        "pergunta": "Como funcionam os materiais de mudança de fase (PCM)?",
        "resposta": "São materiais que absorvem ou liberam calor ao mudar de estado físico. São usados para regular a temperatura em edifícios de forma passiva e eficiente."
    },
    {
        "pergunta": "O que são fibras sintéticas no concreto?",
        "resposta": "São fibras de polipropileno, nylon ou aço adicionadas ao concreto para aumentar a resistência à tração e reduzir fissuras."
    },
    {
        "pergunta": "O que é asfalto borracha?",
        "resposta": "É um tipo de asfalto que utiliza borracha reciclada de pneus. Ele melhora a durabilidade do pavimento e reduz o ruído e impacto ambiental."
    }
]
